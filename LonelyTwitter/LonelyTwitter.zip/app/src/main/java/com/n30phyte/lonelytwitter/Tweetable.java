package com.n30phyte.lonelytwitter;

import java.util.Date;

public interface Tweetable {

    public String getMessage();

    public Date getDate();

}
